import pandas as pd
import joblib

from sklearn.model_selection import train_test_split

from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import LinearSVC

from sklearn.metrics import accuracy_score, classification_report

from feature_extraction import extract_features


# ===================================
# 1. LOAD DATASET
# ===================================

df = pd.read_csv("phishing_site_urls.csv")

print("Dataset loaded successfully")
print(df.head())


# ===================================
# 2. EXTRACT FEATURES
# ===================================

print("\nColumn names:", df.columns.tolist())

X = df["URL"].apply(extract_features)
X = list(X)


# ===================================
# 3. GET LABELS
# ===================================

y = df["Label"]


# ===================================
# 4. CONVERT LABELS
# ===================================

y = y.map({
    "legitimate": 0,
    "phishing": 1,
    "good": 0,
    "bad": 1
})


# ===================================
# 5. REMOVE UNKNOWN LABELS
# ===================================

valid = y.notna()

X = [X[i] for i in range(len(X)) if valid.iloc[i]]
y = y[valid]


# ===================================
# 6. TRAIN-TEST SPLIT
# ===================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)


# ===================================
# 7. MODEL MENU
# ===================================

print("\n===================================")
print("       PHISHING DETECTION MODELS")
print("===================================")

print("1. Random Forest")
print("2. Decision Tree")
print("3. Naive Bayes")
print("4. Support Vector Machine (SVM)")

choice = input("\nEnter your choice (1-4): ")


# ===================================
# 8. RANDOM FOREST
# ===================================

if choice == "1":

    print("\n===================================")
    print("RANDOM FOREST")
    print("===================================")

    model = RandomForestClassifier(
        n_estimators=30,
        max_depth=15,
        random_state=42,
        n_jobs=-1
    )

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)

    print("\nRandom Forest Accuracy:")
    print(accuracy)

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))
 
    joblib.dump(model, "random_forest_model.pkl")

    print("\nModel saved as random_forest_model.pkl")


# ===================================
# 9. DECISION TREE
# ===================================

elif choice == "2":

    print("\n===================================")
    print("DECISION TREE")
    print("===================================")

    model = DecisionTreeClassifier(
        random_state=42
    )

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)

    print("\nDecision Tree Accuracy:")
    print(accuracy)

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    joblib.dump(model, "decision_tree_model.pkl")

    print("\nModel saved as decision_tree_model.pkl")


# ===================================
# 10. NAIVE BAYES
# ===================================

elif choice == "3":

    print("\n===================================")
    print("NAIVE BAYES")
    print("===================================")

    model = GaussianNB()

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)

    print("\nNaive Bayes Accuracy:")
    print(accuracy)

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    joblib.dump(model, "naive_bayes_model.pkl")

    print("\nModel saved as naive_bayes_model.pkl")


# ===================================
# 11. SUPPORT VECTOR MACHINE
# ===================================

elif choice == "4":

    print("\n===================================")
    print("SUPPORT VECTOR MACHINE")
    print("===================================")

    model = LinearSVC(
    random_state=42,
    max_iter=1000
)

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)

    print("\nSVM Accuracy:")
    print(accuracy)

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    joblib.dump(model, "svm_model.pkl")

    print("\nModel saved as svm_model.pkl")


# ===================================
# 12. INVALID CHOICE
# ===================================

else:

    print("\nInvalid choice!")
    print("Please enter a number from 1 to 4.")