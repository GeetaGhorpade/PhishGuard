import re


def extract_features(url):

    features = []

    # URL length
    features.append(len(url))

    # Number of dots
    features.append(url.count("."))

    # Number of hyphens
    features.append(url.count("-"))

    # Number of @ symbols
    features.append(url.count("@"))

    # Number of ?
    features.append(url.count("?"))

    # Number of =
    features.append(url.count("="))

    # Number of /
    features.append(url.count("/"))

    # Number of digits
    features.append(sum(c.isdigit() for c in url))

    # HTTPS
    if url.startswith("https"):
        features.append(1)
    else:
        features.append(0)

    # IP address
    ip_pattern = r'(\d{1,3}\.){3}\d{1,3}'

    if re.search(ip_pattern, url):
        features.append(1)
    else:
        features.append(0)

    return features