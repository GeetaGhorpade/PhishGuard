import os

# Prevent OpenBLAS memory error
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"

from flask import Flask, render_template, request, redirect, url_for
import joblib
import csv
from feature_extraction import extract_features
from datetime import datetime
import pandas as pd

app = Flask(__name__)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATASET_FILE = os.path.join(BASE_DIR, "phishing_site_urls.csv")
PREDICTION_FILE = os.path.join(BASE_DIR, "prediction_results.csv")

# -----------------------------------
# Load trained model
# -----------------------------------

models = {
    "Random Forest": joblib.load(
        os.path.join(BASE_DIR, "random_forest_model.pkl")
    ),

    "Decision Tree": joblib.load(
        os.path.join(BASE_DIR, "decision_tree_model.pkl")
    ),

    "Naive Bayes": joblib.load(
        os.path.join(BASE_DIR, "naive_bayes_model.pkl")
    ),

    "SVM": joblib.load(
        os.path.join(BASE_DIR, "svm_model.pkl")
    )
}

# -----------------------------------
# Home Page
# -----------------------------------

@app.route("/")
def home():
    return render_template("index.html")


# -----------------------------------
# User Registration
# -----------------------------------

@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        password = request.form.get("password")
        confirm_password = request.form.get("confirm_password")

        if password != confirm_password:
            return render_template(
                "register.html",
                message="❌ Passwords do not match!"
            )

        # Registration successful
        return redirect(url_for("login"))

    return render_template("register.html")


# -----------------------------------
# User Login
# -----------------------------------

@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")

        if username and password:
            return redirect(url_for("user_dashboard"))

        return render_template(
            "login.html",
            message="Please enter username and password."
        )

    return render_template("login.html")

# -----------------------------------
# User Dashboard
# -----------------------------------
@app.route("/user_dashboard")
def user_dashboard():
    return render_template("user_dashboard.html")


# -----------------------------------
# Check Website Page
# -----------------------------------
@app.route("/check_website")
def check_website():
    return render_template("check_website.html")


# -----------------------------------
# Information Page
# -----------------------------------
@app.route("/information")
def information():
    return render_template("information.html")

# -----------------------------------
# User Logout
# -----------------------------------
@app.route("/logout")
def logout():
    return redirect(url_for("home"))


# ===================================
# ADMIN SECTION
# ===================================


# -----------------------------------
# Admin Login
# -----------------------------------

@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():

    if request.method == "POST":

        username = request.form.get("username")
        password = request.form.get("password")

        # Admin credentials
        if username == "admin" and password == "admin123":

            return redirect(url_for("admin_dashboard"))

        return render_template(
            "admin_login.html",
            message="❌ Invalid username or password!"
        )

    return render_template("admin_login.html")


# -----------------------------------
# Admin Dashboard
# -----------------------------------

@app.route("/admin_dashboard")
def admin_dashboard():

    # Use the exact CSV files from the project folder
    dataset_file = DATASET_FILE
    prediction_file = PREDICTION_FILE

    # Default values
    total_dataset = 0
    legitimate_count = 0
    phishing_count = 0

    total_predictions = 0
    phishing_predictions = 0
    legitimate_predictions = 0

    recent_results = []

    # =====================================
    # READ ACTUAL DATASET
    # =====================================

    if os.path.exists(dataset_file):

        df = pd.read_csv(dataset_file)

        total_dataset = len(df)

        if "Label" in df.columns:

            legitimate_count = (
                df["Label"]
                .astype(str)
                .str.strip()
                .str.lower()
                .eq("good")
                .sum()
            )

            phishing_count = (
                df["Label"]
                .astype(str)
                .str.strip()
                .str.lower()
                .eq("bad")
                .sum()
            )

    # =====================================
    # READ PREDICTION HISTORY
    # =====================================

    if os.path.exists(prediction_file):

        with open(
            prediction_file,
            "r",
            encoding="utf-8",
            newline=""
        ) as file:

            reader = csv.reader(file)

            for row in reader:

                # Skip header
                if row[:2] == ["URL", "Result"]:
                    continue

                if len(row) >= 2:

                    website_url = row[0].strip()
                    prediction = row[1].strip()

                    total_predictions += 1

                    if prediction == "Phishing Website":
                        phishing_predictions += 1

                    elif prediction == "Legitimate Website":
                        legitimate_predictions += 1

                    recent_results.append({
                        "URL": website_url,
                        "Result": prediction
                    })

    # Latest 5 predictions
    recent_results = recent_results[-5:]
    recent_results.reverse()

    # =====================================
    # MODEL ACCURACY
    # =====================================

    accuracy = "84.57%"

    # =====================================
    # SEND DATA TO HTML
    # =====================================

    return render_template(
        "admin_dashboard.html",

        accuracy=accuracy,

        dataset_name="phishing_site_urls.csv",

        algorithm="Random Forest",

        total_dataset=total_dataset,

        legitimate_count=legitimate_count,

        phishing_count=phishing_count,

        total_predictions=total_predictions,

        phishing_predictions=phishing_predictions,

        legitimate_predictions=legitimate_predictions,

        recent_results=recent_results
    )
@app.route("/model_info")
def model_info():

    model_details = {
        "algorithm": "Random Forest Classifier",
        "model_file": "phishing_model.pkl",
        "accuracy": "84.57%",
        "training": "Supervised Machine Learning",
        "classification": "Binary Classification",
        "classes": "Legitimate / Phishing",
        "n_estimators": "100",
        "random_state": "42"
    }

    return render_template(
        "model_info.html",
        model=model_details
    )


@app.route("/dataset_info")
def dataset_info():
    return render_template("dataset_info.html")


@app.route("/dataset_urls")
def dataset_urls():

    urls = []

    if os.path.exists(DATASET_FILE):

        with open(
            DATASET_FILE,
            "r",
            encoding="utf-8",
            newline=""
        ) as file:

            reader = csv.DictReader(file)

            for row in reader:

                website_url = row.get("URL", "").strip()
                label = row.get("Label", "").strip()

                if website_url:
                    urls.append({
                        "URL": website_url,
                        "Label": label
                    })

    print("TOTAL DATASET URLs:", len(urls))

    return render_template(
        "dataset_urls.html",
        urls=urls
    )
@app.route("/prediction_results")
def prediction_results():

    results = []

    file_name = PREDICTION_FILE

    if os.path.exists(file_name):

        with open(
            file_name,
            "r",
            encoding="utf-8",
            newline=""
        ) as file:

            reader = csv.reader(file)

            for row in reader:

                # Skip header
                if row[:2] == ["URL", "Result"]:
                    continue

                if len(row) >= 2:

                    website_url = row[0].strip()
                    prediction = row[1].strip()

                    results.append({
                        "URL": website_url,
                        "Result": prediction
                    })

    return render_template(
        "prediction_results.html",
        results=results
    )
# -----------------------------------
# Admin Logout
# -----------------------------------

@app.route("/admin_logout")
def admin_logout():

    return redirect(url_for("admin_login"))


# ===================================
# PREDICTION SECTION
# ===================================


# -----------------------------------
# Prediction
# -----------------------------------
@app.route("/predict", methods=["POST"])
def predict():

    # =====================================
    # GET URL
    # =====================================
    url = request.form.get("url", "").strip()
    selected_model = request.form.get("model", "Random Forest")

    if not url:

        return render_template(
        "user_dashboard.html",
        message="Please enter a website URL."
    )  

    # =====================================
    # EXTRACT FEATURES
    # =====================================

    features = extract_features(url)

    # =====================================
    # PREDICT
    # =====================================
    model = models.get(selected_model, models["Random Forest"])

    prediction = model.predict([features])[0]

    if prediction == 1:

        result = "Phishing Website"
        dataset_label = "bad"

    else:

        result = "Legitimate Website"
        dataset_label = "good"

    # =====================================
    # SAVE PREDICTION HISTORY
    # =====================================

    prediction_file = PREDICTION_FILE

    file_exists = os.path.exists(prediction_file)

    with open(
        prediction_file,
        "a",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.writer(file)

        if (
            not file_exists
            or os.path.getsize(prediction_file) == 0
        ):

            writer.writerow(["URL", "Result"])

        writer.writerow([
            url,
            result
        ])

    # =====================================
    # ADD URL TO DATASET
    # =====================================

    dataset_file = DATASET_FILE

    existing_urls = set()

    if os.path.exists(dataset_file):

        with open(
            dataset_file,
            "r",
            encoding="utf-8",
            newline=""
        ) as file:

            reader = csv.DictReader(file)

            for row in reader:

                existing_url = row.get("URL", "").strip()

                if existing_url:

                    existing_urls.add(existing_url)

    # =====================================
    # ADD ONLY NEW URL
    # =====================================

    if url not in existing_urls:

        file_is_empty = (
            not os.path.exists(dataset_file)
            or os.path.getsize(dataset_file) == 0
        )

        with open(
            dataset_file,
            "a",
            newline="",
            encoding="utf-8"
        ) as file:

            writer = csv.writer(file)

            # Add header if CSV is empty
            if file_is_empty:

                writer.writerow([
                    "URL",
                    "Label"
                ])

            # Add new URL
            writer.writerow([
                url,
                dataset_label
            ])

        print("====================================")
        print("NEW URL ADDED TO DATASET")
        print("URL:", url)
        print("LABEL:", dataset_label)
        print("FILE:", dataset_file)
        print("====================================")

    else:

        print("URL ALREADY EXISTS IN DATASET:", url)

    # =====================================
    # DISPLAY RESULT
    # =====================================
    return render_template(
    "result.html",
    url=url,
    result=result,
    model_name=selected_model
)
# -----------------------------------
# Run Application
# -----------------------------------

if __name__ == "__main__":
    app.run(debug=True)